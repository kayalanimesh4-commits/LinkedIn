package com.linkedIn.connection_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
